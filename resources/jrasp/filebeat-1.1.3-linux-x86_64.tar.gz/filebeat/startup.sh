#!/bin/sh
set -e
nohup ./filebeat -c ./filebeat.yml >/dev/null 2>&1 &