#!/bin/bash
ps -ef|grep filebeat|grep -v grep|cut -c 9-15|xargs kill -9
exit 0